#include <iostream>
#include <math.h>
#include <GLFW/glfw3.h>

int main(void)
{
    GLFWwindow* window;

    float c1 = 0.0f, c2 = 0.0f, s1 = 0.0f, s2 = 0.0f;

    //formula for the coordinates of the vertices
    c1 = 0.125f * (sqrt(5) - 1);
    c2 = 0.125f * (sqrt(5) + 1);
    s1 = 0.125f * (sqrt(10 + 2 * sqrt(5)));
    s2 = 0.125f * (sqrt(10 - 2 * sqrt(5)));

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(800, 800, "Andrea Maxene Legaspi", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    /* Make the window's context current */
    glfwMakeContextCurrent(window);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);

        //PENTAGON
        glBegin(GL_POLYGON);
        glVertex2f(0.5f, 0);
        glVertex2f(c1, s1);
        glVertex2f(-1 * c2, s2);
        glVertex2f(-1 * c2, -1 * s2);
        glVertex2f(c1, -1 * s1);
        glEnd();

        /* Swap front and back buffers*/
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glfwTerminate();
    return 0;
}