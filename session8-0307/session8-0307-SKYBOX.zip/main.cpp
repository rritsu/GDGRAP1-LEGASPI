/*
date modified: 03-07-2024 
SKYBOXXX
*/

#include <string>
#include <iostream>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

//bunny
#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//Add in stb_image
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

float x_mod = 0.0f;
float y_mod = 0.0f;

float width = 600.0f;
float height = 600.0f;

float x = 0.0f, y = 0.0f, z = 1.0f;
float scale_x = 1.0f, scale_y = 1.0f, scale_z = 1.0f;
float axis_x = 0.0f, axis_y = 1.0f, axis_z = 0.0f;
float theta_x = 90.0f, theta_y = 0.0f;
float FOV = 10.0f;

glm::mat4 identity_matrix = glm::mat4(1.0f);

void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    //up
    if (key == GLFW_KEY_W)
        y += 1.0f;

    //left
    if (key == GLFW_KEY_A)
        x -= 1.0f;

    //down
    if (key == GLFW_KEY_S)
        y -= 1.0f;

    //right
    if (key == GLFW_KEY_D)
        x += 1.0f;
    
    //rotate up
    if (key == GLFW_KEY_UP)
        theta_y -= 5.0f;

    //rotate down
    if (key == GLFW_KEY_DOWN)
        theta_y += 5.0f;
    
    //rotate right
    if (key == GLFW_KEY_RIGHT)
        theta_x += 5.0f;
    
    //rotate left
    if (key == GLFW_KEY_LEFT)
        theta_x -= 5.0f;

    //decrease
    if (key == GLFW_KEY_Q)
    {
        scale_x -= 0.2f;
        scale_y -= 0.2f;
    }

    //increase
    if (key == GLFW_KEY_E)
    {
        scale_x += 0.2f;
        scale_y += 0.2f;
    }

    //zoom in
    if (key == GLFW_KEY_Z)
        FOV -= 1.5f;

    //zoom out
    if (key == GLFW_KEY_X)
        FOV += 1.5f;

    if (key == GLFW_KEY_I)
        z += 1.0f;

    if (key == GLFW_KEY_K)
        z -= 1.0f;
        
}

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Andrea Maxene Legaspi", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;

    vertBuff << vertSrc.rdbuf();

    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();


    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;

    fragBuff << fragSrc.rdbuf();

    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();
    

    //skybox shader
    std::fstream skyboxVertSrc("Shaders/s.vert");
    std::stringstream skyboxVertBuff;
    skyboxVertBuff << skyboxVertSrc.rdbuf();

    std::string skyboxVertS = skyboxVertBuff.str();
    const char* sky_v = skyboxVertS.c_str();

    //skybox shader
    std::fstream skyboxFragSrc("Shaders/s.frag");
    std::stringstream skyboxFragBuff;

    skyboxFragBuff << skyboxFragSrc.rdbuf();

    std::string sky_frags = skyboxFragBuff.str();
    const char* sky_f = sky_frags.c_str();

    
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0,
               0,
               600,
               600);

    int img_width, //width of the texture
        img_height, //height of the texture
        colorChannels; //number of color channels

    //FLIP
    stbi_set_flip_vertically_on_load(true);

    //load the texture and fill out the variables
    unsigned char* tex_bytes =      
        stbi_load("3D/partenza.jpg",   //texture path
                  &img_width,       //fills out the width
                  &img_height,      //fills out the height
                  &colorChannels,   //fills out the color channels
                  0);

    glfwSetKeyCallback(window, Key_Callback);


    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &v, NULL);
    glCompileShader(vertexShader);

    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, &f, NULL);
    glCompileShader(fragShader);

    GLuint shaderProg = glCreateProgram();
    glAttachShader(shaderProg, vertexShader);
    glAttachShader(shaderProg, fragShader);

    glLinkProgram(shaderProg);

    //link skybox shader
    GLuint vertexShaderSkybox = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShaderSkybox, 1, &sky_v, NULL);
    glCompileShader(vertexShaderSkybox);

    GLuint fragShaderSkybox = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShaderSkybox, 1, &sky_f, NULL);
    glCompileShader(fragShaderSkybox);

    GLuint skyboxShaderProg = glCreateProgram();
    glAttachShader(skyboxShaderProg, vertexShaderSkybox);
    glAttachShader(skyboxShaderProg, fragShaderSkybox);

    glLinkProgram(skyboxShaderProg);
    //cleanup
    glDeleteShader(vertexShaderSkybox);
    glDeleteShader(fragShaderSkybox);

    //OpenGL reference to the texture
    GLuint texture;
    glGenTextures(1, &texture);     //generate a reference
    glActiveTexture(GL_TEXTURE0);   //set the current texture we're working on to Texture 0
    glBindTexture(GL_TEXTURE_2D, texture);  //bind our next tasks to Tex0 to our current reference similar to what we're doing to VBOs

    //assign the loaded texture to the OpenGL reference
    glTexImage2D(GL_TEXTURE_2D,
        0,  //texture 0 
        GL_RGB,    //target color format of the texture
        img_width,  //texture width
        img_height, //texture height
        0,
        GL_RGB,    //color format of the texture
        GL_UNSIGNED_BYTE,
        tex_bytes); //loaded texture in bytes

    //NOTE: PNG often uses RGBA because it has transparency or alpha layer, while JPG/JPEG often uses RGB

    //generate the mipmaps ot the current texture
    //MIPMAPS are smaller versions of the texture
    //used when an object is too far/small so it won't try to map the full-size texture and instead generates smaller versions to save memory
    glGenerateMipmap(GL_TEXTURE_2D);
    //free up the loaded bytes
    stbi_image_free(tex_bytes);

    //enable depth testing
    glEnable(GL_DEPTH_TEST);

    //LIGHTING
    glm::vec3 lightPos = glm::vec3(-10, 1, 10);
    glm::vec3 lightColor = glm::vec3(1, 1, 1); //white

    float ambientStr = 0.3f;
    glm::vec3 ambientColor = lightColor;

    float specStr = 0.5f;
    float specPhong = 12;
    float brightness = 2.0f;

    std::string path = "3D/djSword.obj";
    std::vector <tinyobj::shape_t> shapes;
    std::vector <tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;
    //myCube has 8 points and 24 vertices (8 * 3), 3 refers to the 
    bool success = tinyobj::LoadObj(&attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLfloat> fullVertexData;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        //mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
        tinyobj::index_t vData = shapes[0].mesh.indices[i]; //vData accesses vertex indices 

        //push the X position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3)] //multiply the index by 3 to get the base offset
        );

        //push the Y position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3) + 1]  //add the base offset by 1 to get Y
        );

        //push the Z position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3) + 2]   //add the base offset by 1 to get Z
        );

        //push the X normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3)]
        );

        //push the Y normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3) + 1]
        );

        //push the Z normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3) + 2]
        );

        //push the U of the Tex Coords
        fullVertexData.push_back(
            attributes.texcoords[(vData.texcoord_index * 2)] //multiply the index by 2 to get the base offset
        );

        //push the U of the Tex Coords
        fullVertexData.push_back(
            attributes.texcoords[(vData.texcoord_index * 2) + 1] //add the base offset by 1 to get V
        );

        
    }
   //make attrib pointer for normals
    GLfloat vertices[]
    {
        0.f, 0.5f, 0.f,     //0
        -0.5f, -0.5f, 0.f,  //1
        0.5f, -0.5f, 0.f    //2
    };

    GLuint indices[]{
        0,1,2
    };

    //manually define UVs for now
    GLfloat UV[]{
        0.f, 1.f,
        0.f, 0.f,
        1.f, 1.f,
        1.f, 0.f,
        1.f, 1.f,
        1.f, 0.f,
        0.f, 1.f,
        0.f, 0.f
    }; //8 points to render the cube
    
    //dito
    GLuint VAO, VBO;
    

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    //glGenBuffers(1, &EBO);
    //glGenBuffers(1, &VBO_UV);

    //Currently editing VAO = null
    glBindVertexArray(VAO);
    //Currently editing VAO = VAO

    //Currently editing VBO = null
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Currently editing VBO = VBO
    //VAO <- VBO

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(GLfloat)* fullVertexData.size(),
        //data of the array
        fullVertexData.data(),
        GL_DYNAMIC_DRAW
    );

    glVertexAttribPointer(
        0,
        3,
        GL_FLOAT,
        GL_FALSE,
        8 * sizeof(float),
        (void*)0
    );
    glEnableVertexAttribArray(0);

    GLintptr normalPtr = 3 * sizeof(float);
    glVertexAttribPointer(
        1,
        3,
        GL_FLOAT,
        GL_FALSE,
        8 * sizeof(float),
        (void*)normalPtr
    );
    glEnableVertexAttribArray(1);

    //since our UV starts at index 3 
    GLintptr uvPtr = 6 * sizeof(float);
    glVertexAttribPointer(
        2, //index 2 = tex coords
        2, //UV is 2 floats
        GL_FLOAT,
        GL_FALSE,
        8 * sizeof(float),
        (void*)uvPtr
    );
    glEnableVertexAttribArray(2);
    

    //Currently editing VBO = VBO
    
   
   // glEnableVertexAttribArray(0);
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    //glBindVertexArray(VAO);

        //SKYBOX
    /*
  7--------6
 /|       /|
4--------5 |
| |      | |
| 3------|-2
|/       |/
0--------1
*/
//Vertices for the cube
    float skyboxVertices[]{
        -1.f, -1.f, 1.f, //0
        1.f, -1.f, 1.f,  //1
        1.f, -1.f, -1.f, //2
        -1.f, -1.f, -1.f,//3
        -1.f, 1.f, 1.f,  //4
        1.f, 1.f, 1.f,   //5
        1.f, 1.f, -1.f,  //6
        -1.f, 1.f, -1.f  //7
    };

    //Skybox Indices
    unsigned int skyboxIndices[]{
        1,2,6,
        6,5,1,

        0,4,7,
        7,3,0,

        4,5,6,
        6,7,4,

        0,3,2,
        2,1,0,

        0,1,5,
        5,4,0,

        3,7,6,
        6,2,3
    };


    //SKYBOX
        //skybox VAO, VBO AND EBO
    unsigned int skyboxVAO, skyboxVBO, skyboxEBO;
    glGenVertexArrays(1, &skyboxVAO);
    glGenBuffers(1, &skyboxVBO);
    glGenBuffers(1, &skyboxEBO);
    //EBO

    glBindVertexArray(skyboxVAO);
    glBindBuffer(GL_ARRAY_BUFFER, skyboxVBO);
    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(skyboxVertices),
        &skyboxVertices,
        GL_STATIC_DRAW
    );
    glVertexAttribPointer(
        0, //index 2 = tex coords
        3, //UV is 2 floats
        GL_FLOAT,
        GL_FALSE,
        3 * sizeof(float),
        (void*)0
    );
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, skyboxEBO);
    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GL_INT) * 36,
        &skyboxIndices,
        GL_STATIC_DRAW
    );
    glEnableVertexAttribArray(0);

    /*
    std::string facesSkyboxAA[]{
         "Skybox/py.png",
         "Skybox/nx.png",
         "Skybox/py.png",
         "Skybox/ny.png",
         "Skybox/pz.png",
         "Skybox/nz.png"
    };
    */
    
    std::string facesSkyboxaaa[]{
        "Skybox/ocean_rt.png",
        "Skybox/ocean_lf.png",
        "Skybox/ocean_up.png",
        "Skybox/ocean_dn.png",
        "Skybox/ocean_ft.png",
        "Skybox/ocean_bk.png"
    };

    
    std::string facesSkybox[]{
        "Skybox/rainbow_rt.png",    //right
        "Skybox/rainbow_lf.png",    //left
        "Skybox/rainbow_up.png",    //up
        "Skybox/rainbow_dn.png",    //down
        "Skybox/rainbow_ft.png",    //front
        "Skybox/rainbow_bk.png",    //back
    };
    

    //skybox texture
    unsigned int skyboxTex;
    
    //generate skybox textue
    glGenTextures(1, &skyboxTex);
    glBindTexture(GL_TEXTURE_CUBE_MAP, skyboxTex);

    //to avoid pixelating when its too big / small
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_MIN_FILTER, GL_LINEAR);

    //instead of ST only - Cubemaps rely on RST
    //to make sure the texture is stretched to the edge
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_R, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
    glTexParameteri(GL_TEXTURE_CUBE_MAP, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
    
    //for loop to load the textures
    for (unsigned int i = 0; i < 6; i++) {
        int w, h, skyCChannel;
        stbi_set_flip_vertically_on_load(false);
        unsigned char* data = stbi_load(facesSkybox[i].c_str(), &w, &h, &skyCChannel, 0);

        if (data){
            glTexImage2D(
                GL_TEXTURE_CUBE_MAP_POSITIVE_X + i,
                0,
                GL_RGB,
                w,
                h,
                0,
                GL_RGB,
                GL_UNSIGNED_BYTE,
                data
            );
            stbi_image_free(data);

        }
    }
    stbi_set_flip_vertically_on_load(true);

    /*
    //to know whether to use RGB or RGBA
    if(CChannel == 3)
         // RGB
    else 
         //RGBA
    */


    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); //clear the depth buffer as well

        glm::mat4 transformation_matrix;
        transformation_matrix = glm::translate(
            identity_matrix,
            glm::vec3(x, y, z)
        );

       transformation_matrix = glm::scale(
            transformation_matrix,
            glm::vec3(scale_x, scale_y, scale_z)
        );
        
        transformation_matrix = glm::rotate(
            transformation_matrix,
            glm::radians(theta_y),
            glm::normalize(glm::vec3(1, 0, 0))
        );

        transformation_matrix = glm::rotate(
            transformation_matrix,
            glm::radians(theta_x),
            glm::normalize(glm::vec3(0, 1, 0))
        );


        glm::mat4 projection = glm::perspective(
            glm::radians(FOV),  //FOV
            height / width, //aspect ratio
            0.1f, //near
            500.f // far
        );

        //z needs to be positive, if negative rabbit will be displayed behind the camera(?)
        //position of the camera in the world / Eye
        glm::vec3 cameraPos = glm::vec3(0, 0, 100.0f);

        //construct the position matrix using the eye
        glm::mat4 cameraPositionMatrix =
            glm::translate(glm::mat4(1.0f),  //initialize it as an identity matrix
                cameraPos * -1.0f);          //multiply to -1 since we need -P

        //world's Up direction
        //nnormally just 1 in Y
        //these may be placed outside main(?) instead
        glm::vec3 WorldUp = glm::vec3(0, 1.0f, 0); //usually always 0 1 0
        glm::vec3 Center = glm::vec3(0, 0.f, 0);

        //get the Forward
        glm::vec3 F = glm::vec3(Center - cameraPos);
        F = glm::normalize(F); //normalize the Forward

        //get the Right
        glm::vec3 R = glm::normalize(
            glm::cross(F, WorldUp) //F x WorldUp
        );

        //get the Up
        glm::vec3 U = glm::normalize(
            glm::cross(R, F) //R x F
        );

        //contruct the Camera Orientation Matrix
        glm::mat4 cameraOrientation = glm::mat4(1.f);

        glm::mat4 viewMatrix = glm::lookAt(cameraPos, Center, WorldUp);


        glDepthMask(GL_FALSE);
        glDepthFunc(GL_LEQUAL);
        glUseProgram(skyboxShaderProg);

        glm::mat4 sky_view = glm::mat4(1.f);
        sky_view = glm::mat4(glm::mat3(viewMatrix));

      //  glDepthMask(GL_FALSE);
      //  glDepthFunc(GL_LEQUAL);
      //  glUseProgram(skyboxShaderProg);

        unsigned int skyboxViewLoc = glGetUniformLocation(skyboxShaderProg, "view");
        glUniformMatrix4fv(skyboxViewLoc,  //address of the variable
            1,        //how many variables are we modifying 
            GL_FALSE,
            glm::value_ptr(sky_view)); //view Matrix

        //projection
        unsigned int skyboxProjLoc = glGetUniformLocation(skyboxShaderProg, "projection");
        glUniformMatrix4fv(skyboxProjLoc,  //address of the variable
            1,        //how many variables are we modifying 
            GL_FALSE,
            glm::value_ptr(projection)); //projection matrix

      

     //   glm::mat4 sky_view = glm::mat4(1.f);
       // sky_view = glm::mat4(glm::mat3(viewMatrix));

        glBindVertexArray(skyboxVAO);
        glActiveTexture(GL_TEXTURE0);
        glBindTexture(GL_TEXTURE_CUBE_MAP, skyboxTex);
        glDrawElements(GL_TRIANGLES, 36, GL_UNSIGNED_INT, 0);
        glDepthMask(GL_TRUE);
        glDepthFunc(GL_LESS);

        glUseProgram(shaderProg);
        
        //view
        unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");
        glUniformMatrix4fv(viewLoc,  //address of the variable
            1,        //how many variables are we modifying 
            GL_FALSE,
            glm::value_ptr(viewMatrix)); //view Matrix


        unsigned int transformloc = glGetUniformLocation(shaderProg, "transform");
        glUniformMatrix4fv(transformloc,
            1,
            GL_FALSE,
            glm::value_ptr(transformation_matrix));

        //projection
        unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
        glUniformMatrix4fv(projLoc,  //address of the variable
            1,        //how many variables are we modifying 
            GL_FALSE,
            glm::value_ptr(projection)); //projection matrix

        //CAMERA
        GLuint cameraPosAddress = glGetUniformLocation(shaderProg, "cameraPos");
        glUniform3fv(cameraPosAddress, 1, glm::value_ptr(cameraPos));

        //LIGHTING
        GLuint lightAddress = glGetUniformLocation(shaderProg, "lightPos");
        glUniform3fv(lightAddress, 1, glm::value_ptr(lightPos));

        GLuint lightColorAddress = glGetUniformLocation(shaderProg, "lightColor");
        glUniform3fv(lightColorAddress, 1, glm::value_ptr(lightColor));

        GLuint ambientStrAddress = glGetUniformLocation(shaderProg, "ambientStr");
        glUniform1f(ambientStrAddress, ambientStr);

        GLuint ambientColorAddress = glGetUniformLocation(shaderProg, "ambientColor");
        glUniform3fv(ambientColorAddress, 1, glm::value_ptr(ambientColor));

        GLuint specStrAddress = glGetUniformLocation(shaderProg, "specStr");
        glUniform1f(specStrAddress, specStr);

        GLuint brightnessAddress = glGetUniformLocation(shaderProg, "brightness");
        glUniform1f(brightnessAddress, brightness);

        GLuint specPhongAddress = glGetUniformLocation(shaderProg, "specPhong");
        glUniform1f(specPhongAddress, specPhong);

        GLuint tex0Address = glGetUniformLocation(shaderProg, "tex0");
        glBindTexture(GL_TEXTURE_2D, texture);
        glUniform1i(tex0Address, 0);

        glBindVertexArray(VAO);

        //3rd paramter refers to the number of vertices
        glDrawArrays(GL_TRIANGLES, 0, fullVertexData.size() / 5);

       
        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    //glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}