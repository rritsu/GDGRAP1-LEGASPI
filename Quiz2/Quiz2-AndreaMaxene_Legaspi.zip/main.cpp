/*
date modified: 03-07-2024
quiz #2
*/

#include <string>
#include <iostream>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

//Add in stb_image
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"

float width = 600.0f;
float height = 600.0f;

float x = 0.0f, y = 0.0f, z = 1.0f;
float scale_x = 1.0f, scale_y = 1.0f, scale_z = 1.0f;
float axis_x = 0.0f, axis_y = 1.0f, axis_z = 0.0f;
float theta = 90.0f;
float FOV = 90.0f;

glm::mat4 identity_matrix = glm::mat4(1.0f);

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Andrea Maxene Legaspi", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;

    vertBuff << vertSrc.rdbuf();

    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();


    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;

    fragBuff << fragSrc.rdbuf();

    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();

    
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0, 0, 600, 600);

    int img_width, //width of the texture
        img_height, //height of the texture
        colorChannels; //number of color channels

    //FLIP
    stbi_set_flip_vertically_on_load(true);

    //load the texture and fill out the variables
    unsigned char* tex_bytes =      
        stbi_load("3D/partenza.jpg",   //texture path
                  &img_width,       //fills out the width
                  &img_height,      //fills out the height
                  &colorChannels,   //fills out the color channels
                  0);

    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &v, NULL);
    glCompileShader(vertexShader);

    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, &f, NULL);
    glCompileShader(fragShader);

    GLuint shaderProg = glCreateProgram();
    glAttachShader(shaderProg, vertexShader);
    glAttachShader(shaderProg, fragShader);

    glLinkProgram(shaderProg);

    //OpenGL reference to the texture
    GLuint texture;
    glGenTextures(1, &texture);    
    glActiveTexture(GL_TEXTURE0);   
    glBindTexture(GL_TEXTURE_2D, texture);  

    glTexImage2D(GL_TEXTURE_2D,
        0,  
        GL_RGB,    
        img_width,  
        img_height, 
        0,
        GL_RGB,    
        GL_UNSIGNED_BYTE,
        tex_bytes); 

    glGenerateMipmap(GL_TEXTURE_2D);
    stbi_image_free(tex_bytes);

    glEnable(GL_DEPTH_TEST);

    //LIGHTING
    glm::vec3 lightPos = glm::vec3(-10, 1, 10);
    glm::vec3 lightColor = glm::vec3(0, 1, 0);
    glm::vec3 lightDirection = glm::vec3(-1, -1, 0); 

    float ambientStr = 0.3f;
    glm::vec3 ambientColor = lightColor;

    float specStr = 0.5f;
    float specPhong = 12;
    float brightness = 2.0f;


    std::string path = "3D/quiz.obj";
    std::vector <tinyobj::shape_t> shapes;
    std::vector <tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;
    bool success = tinyobj::LoadObj(&attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLfloat> fullVertexData;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        tinyobj::index_t vData = shapes[0].mesh.indices[i]; //vData accesses vertex indices 

        //push the X position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3)] //multiply the index by 3 to get the base offset
        );

        //push the Y position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3) + 1]  //add the base offset by 1 to get Y
        );

        //push the Z position of the vertex
        fullVertexData.push_back(
            attributes.vertices[(vData.vertex_index * 3) + 2]   //add the base offset by 1 to get Z
        );

        //push the X normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3)]
        );

        //push the Y normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3) + 1]
        );

        //push the Z normal
        fullVertexData.push_back(
            attributes.normals[(vData.normal_index * 3) + 2]
        );
   
    }

    GLuint VAO, VBO;
   
    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(VAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);

    glBufferData(
        GL_ARRAY_BUFFER,
        sizeof(GLfloat)* fullVertexData.size(),
        fullVertexData.data(),
        GL_DYNAMIC_DRAW
    );

    glVertexAttribPointer(
        0,
        3,
        GL_FLOAT,
        GL_FALSE,
        6 * sizeof(float),
        (void*)0
    );
    glEnableVertexAttribArray(0);

    GLintptr normalPtr = 3 * sizeof(float);
    glVertexAttribPointer(
        1,
        3,
        GL_FLOAT,
        GL_FALSE,
        6 * sizeof(float),
        (void*)normalPtr
    );
    glEnableVertexAttribArray(1);


    GLintptr uvPtr = 6 * sizeof(float);
    glVertexAttribPointer(
        2, 
        2, 
        GL_FLOAT,
        GL_FALSE,
        6 * sizeof(float),
        (void*)uvPtr
    );
    glEnableVertexAttribArray(2);
   
    
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT); 

        theta += 0.01f;

        glm::mat4 transformation_matrix = glm::translate(identity_matrix,glm::vec3(x, y, z));
        transformation_matrix = glm::scale(transformation_matrix,glm::vec3(scale_x, scale_y, scale_z));
        transformation_matrix = glm::rotate(transformation_matrix,glm::radians(theta),glm::normalize(glm::vec3(axis_x, axis_y, axis_z)));
        glm::mat4 projection = glm::perspective(glm::radians(FOV), height / width, 0.1f, 500.f);

        //position of the camera in the world / Eye
        glm::vec3 cameraPos = glm::vec3(0, 0, 100.0f);
        glm::vec3 WorldUp = glm::vec3(0, 1.0f, 0); 
        glm::vec3 Center = glm::vec3(0, 0.f, 0);

        glm::mat4 viewMatrix = glm::lookAt(cameraPos, Center, WorldUp);

        glUseProgram(shaderProg);

        unsigned int transformloc = glGetUniformLocation(shaderProg, "transform");
        glUniformMatrix4fv(transformloc, 1, GL_FALSE, glm::value_ptr(transformation_matrix));

        unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
        glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection)); 

        unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");    
        glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(viewMatrix)); 

        GLuint cameraPosAddress = glGetUniformLocation(shaderProg, "cameraPos");
        glUniform3fv(cameraPosAddress, 1, glm::value_ptr(cameraPos));

        GLuint lightAddress = glGetUniformLocation(shaderProg, "lightPos");
        glUniform3fv(lightAddress, 1, glm::value_ptr(lightPos));

        GLuint lightColorAddress = glGetUniformLocation(shaderProg, "lightColor");
        glUniform3fv(lightColorAddress, 1, glm::value_ptr(lightColor));

        GLuint lightDirectionAddress = glGetUniformLocation(shaderProg, "lightDirection");
        glUniform3fv(lightDirectionAddress, 1, glm::value_ptr(lightDirection));

        GLuint ambientStrAddress = glGetUniformLocation(shaderProg, "ambientStr");
        glUniform1f(ambientStrAddress, ambientStr);

        GLuint ambientColorAddress = glGetUniformLocation(shaderProg, "ambientColor");
        glUniform3fv(ambientColorAddress, 1, glm::value_ptr(ambientColor));

        GLuint specStrAddress = glGetUniformLocation(shaderProg, "specStr");
        glUniform1f(specStrAddress, specStr);

        GLuint brightnessAddress = glGetUniformLocation(shaderProg, "brightness");
        glUniform1f(brightnessAddress, brightness);

        GLuint specPhongAddress = glGetUniformLocation(shaderProg, "specPhong");
        glUniform1f(specPhongAddress, specPhong);

        GLuint tex0Address = glGetUniformLocation(shaderProg, "tex0");
        glBindTexture(GL_TEXTURE_2D, texture);
        glUniform1i(tex0Address, 0);

        glBindVertexArray(VAO);

        //3rd paramter refers to the number of vertices
        glDrawArrays(GL_TRIANGLES, 0, fullVertexData.size() / 6);

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);

    glfwTerminate();
    return 0;
}