/*
date modified: 02-07-2024 
caught up and updated
*/

#include <string>
#include <iostream>

#include <glad/glad.h>
#include <GLFW/glfw3.h>

#define TINYOBJLOADER_IMPLEMENTATION
#include "tiny_obj_loader.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

float x_mod = 0.0f;
float y_mod = 0.0f;

float width = 600.0f;
float height = 600.0f;

float x = 0.0f, y = 0.0f, z = 1.0f;
float scale_x = 3.0f, scale_y = 3.0f, scale_z = 3.0f;
float axis_x = 0.0f, axis_y = 1.0f, axis_z = 0.0f;
float theta_x = 90.0f, theta_y = 0.0f;
float FOV = 60.0f;

glm::mat4 identity_matrix = glm::mat4(1.0f);

void Key_Callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
    //up
    if (key == GLFW_KEY_W)
        y += 0.1f;

    //left
    if (key == GLFW_KEY_A)
        x -= 0.1f;

    //down
    if (key == GLFW_KEY_S)
        y -= 0.1f;

    //right
    if (key == GLFW_KEY_D)
        x += 0.1f;
    
    //rotate up
    if (key == GLFW_KEY_UP)
        theta_y -= 5.0f;

    //rotate down
    if (key == GLFW_KEY_DOWN)
        theta_y += 5.0f;
    
    //rotate right
    if (key == GLFW_KEY_RIGHT)
        theta_x += 5.0f;
    
    //rotate left
    if (key == GLFW_KEY_LEFT)
        theta_x -= 5.0f;

    //decrease
    if (key == GLFW_KEY_Q)
    {
        scale_x -= 0.5f;
        scale_y -= 0.5f;
    }

    //increase
    if (key == GLFW_KEY_E)
    {
        scale_x += 0.5f;
        scale_y += 0.5f;
    }

    //zoom in
    if (key == GLFW_KEY_Z)
        FOV -= 1.5f;

    //zoom out
    if (key == GLFW_KEY_X)
        FOV += 1.5f;
}

int main(void)
{
    GLFWwindow* window;

    /* Initialize the library */
    if (!glfwInit())
        return -1;

    /* Create a windowed mode window and its OpenGL context */
    window = glfwCreateWindow(width, height, "Andrea Maxene Legaspi", NULL, NULL);
    if (!window)
    {
        glfwTerminate();
        return -1;
    }

    std::fstream vertSrc("Shaders/sample.vert");
    std::stringstream vertBuff;

    vertBuff << vertSrc.rdbuf();

    std::string vertS = vertBuff.str();
    const char* v = vertS.c_str();


    std::fstream fragSrc("Shaders/sample.frag");
    std::stringstream fragBuff;

    fragBuff << fragSrc.rdbuf();

    std::string fragS = fragBuff.str();
    const char* f = fragS.c_str();

    
    /* Make the window's context current */
    glfwMakeContextCurrent(window);
    gladLoadGL();

    glViewport(0,
               0,
               600,
               600);

    glfwSetKeyCallback(window, Key_Callback);


    GLuint vertexShader = glCreateShader(GL_VERTEX_SHADER);
    glShaderSource(vertexShader, 1, &v, NULL);
    glCompileShader(vertexShader);

    GLuint fragShader = glCreateShader(GL_FRAGMENT_SHADER);
    glShaderSource(fragShader, 1, &f, NULL);
    glCompileShader(fragShader);

    GLuint shaderProg = glCreateProgram();
    glAttachShader(shaderProg, vertexShader);
    glAttachShader(shaderProg, fragShader);

    glLinkProgram(shaderProg);

    std::string path = "3D/bunny.obj";
    std::vector <tinyobj::shape_t> shapes;
    std::vector <tinyobj::material_t> material;
    std::string warning, error;

    tinyobj::attrib_t attributes;

    bool success = tinyobj::LoadObj(&attributes,
        &shapes,
        &material,
        &warning,
        &error,
        path.c_str()
    );

    std::vector<GLuint> mesh_indices;
    for (int i = 0; i < shapes[0].mesh.indices.size(); i++)
    {
        mesh_indices.push_back(shapes[0].mesh.indices[i].vertex_index);
    }
   
    GLfloat vertices[]
    {
        0.f, 0.5f, 0.f,     //0
        -0.5f, -0.5f, 0.f,  //1
        0.5f, -0.5f, 0.f    //2
    };

    GLuint indices[]{
        0,1,2
    };

    GLuint VAO, VBO, EBO;

    glGenVertexArrays(1, &VAO);
    glGenBuffers(1, &VBO);
    glGenBuffers(1, &EBO);

    //Currently editing VAO = null
    glBindVertexArray(VAO);
    //Currently editing VAO = VAO

    //Currently editing VBO = null
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    //Currently editing VBO = VBO
    //VAO <- VBO

    glBufferData(GL_ARRAY_BUFFER,
        sizeof(GL_FLOAT) * attributes.vertices.size(), //size in bytes
        &attributes.vertices[0], //array
        GL_STATIC_DRAW
    );

    glVertexAttribPointer
    (   0,                 //0 pos, 1 = norm, 2 = texture
        3,                 //X Y Z components
        GL_FLOAT,
        GL_FALSE,
        3 * sizeof(float),
        (void*)0
    );

    //Currently editing VBO = VBO
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO);
    //Currently editing VBO = EBO

    glBufferData(
        GL_ELEMENT_ARRAY_BUFFER,
        sizeof(GLuint) * mesh_indices.size(),
        &mesh_indices[0],
        GL_STATIC_DRAW
    );
   
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, 0);
    glBindVertexArray(0);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

    glBindVertexArray(VAO);

    

    /* Loop until the user closes the window */
    while (!glfwWindowShouldClose(window))
    {
        /* Render here */
        glClear(GL_COLOR_BUFFER_BIT);

        glm::mat4 transformation_matrix;
        transformation_matrix = glm::translate(
            identity_matrix,
            glm::vec3(x, y, z)
        );

       transformation_matrix = glm::scale(
            transformation_matrix,
            glm::vec3(scale_x, scale_y, scale_z)
        );
        
        transformation_matrix = glm::rotate(
            transformation_matrix,
            glm::radians(theta_y),
            glm::normalize(glm::vec3(1, 0, 0))
        );

        transformation_matrix = glm::rotate(
            transformation_matrix,
            glm::radians(theta_x),
            glm::normalize(glm::vec3(0, 1, 0))
        );

        //orthographic
        /*glm::mat4 projection = glm::ortho(-1.0f,  //left most point
                                           1.0f,  //right most point
                                          -1.0f,  //bottom most point
                                           1.0f,  //top most point
                                          -1.0f,  //z near
                                           1.0f); //z far
                                           */
                                        
        glm::mat4 projection = glm::perspective(
            glm::radians(FOV),  //FOV
            height / width, //aspect ratio
            0.1f, //near
            100.f // far
        );

        //z needs to be positive, if negative rabbit will be displayed behind the camera(?)
        //position of the camera in the world / Eye
        glm::vec3 cameraPos = glm::vec3(0, 0, 10.0f);

        //construct the position matrix using the eye
        glm::mat4 cameraPositionMatrix =
            glm::translate(glm::mat4(1.0f),  //initialize it as an identity matrix
                cameraPos * -1.0f);          //multiply to -1 since we need -P

        //world's Up direction
        //nnormally just 1 in Y
        //these may be placed outside main(?) instead
        glm::vec3 WorldUp = glm::vec3(0, 1.0f, 0);
        glm::vec3 Center = glm::vec3(0, 3.f, 0);

        //get the Forward
        glm::vec3 F = glm::vec3(Center - cameraPos);
        F = glm::normalize(F); //normalize the Forward

        //get the Right
        glm::vec3 R = glm::normalize(
            glm::cross(F, WorldUp) //F x WorldUp
        );

        //get the Up
        glm::vec3 U = glm::normalize(
            glm::cross(R, F) //R x F
        );

        //contruct the Camera Orientation Matrix
        glm::mat4 cameraOrientation = glm::mat4(1.f);

        //manually assign the Matrix
        //Matrix[Column][Row]
        /*cameraOrientation[0][0] = R.x;
        cameraOrientation[1][0] = R.y;
        cameraOrientation[2][0] = R.z;

        cameraOrientation[0][1] = U.x;
        cameraOrientation[1][1] = U.y;
        cameraOrientation[2][1] = U.z;

        cameraOrientation[0][2] = -F.x;
        cameraOrientation[1][2] = -F.y;
        cameraOrientation[2][2] = -F.z;

        //camera View Matrix
        glm::mat4 viewMatrix = cameraOrientation * cameraPositionMatrix;*/

        glm::mat4 viewMatrix = glm::lookAt(cameraPos, Center, WorldUp);

        glUseProgram(shaderProg);

        unsigned int transformloc = glGetUniformLocation(shaderProg, "transform");
        glUniformMatrix4fv(transformloc,
                           1,
                           GL_FALSE,
                           glm::value_ptr(transformation_matrix));

        //projection
        unsigned int projLoc = glGetUniformLocation(shaderProg, "projection");
        glUniformMatrix4fv(projLoc,  //address of the variable
                           1,        //how many variables are we modifying 
                           GL_FALSE,
                           glm::value_ptr(projection)); //projection matrix

        //view
        unsigned int viewLoc = glGetUniformLocation(shaderProg, "view");
        glUniformMatrix4fv(viewLoc,  //address of the variable
            1,        //how many variables are we modifying 
            GL_FALSE,
            glm::value_ptr(viewMatrix)); //view Matrix
        
        //unsigned int xLoc = glGetUniformLocation(shaderProg, "x");
        //glUniform1f(xLoc, x_mod);
        //unsigned int yLoc = glGetUniformLocation(shaderProg, "y");
        //glUniform1f(yLoc, y_mod);

        glBindVertexArray(VAO);
        glDrawElements(GL_TRIANGLES, mesh_indices.size(), GL_UNSIGNED_INT, 0);

        /* Swap front and back buffers */
        glfwSwapBuffers(window);

        /* Poll for and process events */
        glfwPollEvents();
    }

    glDeleteVertexArrays(1, &VAO);
    glDeleteBuffers(1, &VBO);
    glDeleteBuffers(1, &EBO);

    glfwTerminate();
    return 0;
}